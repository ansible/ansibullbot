Revision Request
================

Hi!

Thanks very much for your submission to Ansible.  It sincerely means a lot to us. 

We'd like to see a few things tweaked if you don't mind.  If you can help resolve these items, we'd greatly appreciate it:

   * (A) INSERT ITEM HERE

Just as a quick reminder of things, this is a really busy project.  We have over 800 contributors and to manage the queue effectively
we assign things a priority between P1 (highest) and P5.  We'd like to thank you very much for your time!  
We'll work things in priority order, so just wanted you to be aware of the queue and know we haven't forgotten about you!

We will definitely see your comments on this issue when reading this ticket, but may not be able to reply promptly.  You may also wish to join one of our two mailing lists
which are very active:

   * https://groups.google.com/forum/#!forum/ansible-project - for user questions, tips, and tricks
   * https://groups.google.com/forum/#!forum/ansible-devel - for strategy, future planning, and questions about writing code

Thank you once again for this and your interest in Ansible!

