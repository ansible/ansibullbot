Is This A Bug?
==============

Hi!

Thanks very much for your submission to Ansible.  It sincerely means a lot to us.

We're not sure this is a bug, and we don't mean for this to be confrontational.  Let's explain what we're thinking:

   * INSERT ITEM HERE

As such, we're going to close this ticket.  However, we're open to being corrected, should you wish to discuss.  You can stop by one of our two mailing lists 
to talk about this and we might be persuaded otherwise.
   
   * https://groups.google.com/forum/#!forum/ansible-project - for user questions, tips, and tricks
   * https://groups.google.com/forum/#!forum/ansible-devel - for strategy, future planning, and questions about writing code

Comments on closed tickets aren't something we monitor, so if you do disagree with this, a mailing list thread is probably appropriate.

Thank you once again for this and your interest in Ansible!

