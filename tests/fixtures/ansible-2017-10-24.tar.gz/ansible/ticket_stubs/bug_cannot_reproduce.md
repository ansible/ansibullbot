Cannot Reproduce
================

Hi!

Thanks very much for your submission to Ansible.  It sincerely means a lot to us. 

Testing this on the version you have specified, we cannot reproduce this problem.

Our reasons and evidence for this are:

   * INSERT HERE

And we suggest that:

   * INSERT THINGS TO DO HERE

As such, we are most likely going to close this ticket.  Should you disagree with this conclusion, you may also wish to join our mailing lists, which are very active:

   * https://groups.google.com/forum/#!forum/ansible-project - for user questions, tips, and tricks
   * https://groups.google.com/forum/#!forum/ansible-devel - for strategy, future planning, and questions about writing code

Thank you once again for this and your interest in Ansible!



