Confirmed, Thanks!
==================

Hi!

Thanks very much for your submission to Ansible.  It sincerely means a lot to us.

We've confirmed this is an issue and have marked as a high priority item to resolve.

Additionally:

   * INSERT REASONS!

We will definitely see your comments on this issue when reading this ticket, but may not be able to reply promptly.  You may also wish to join one of our two mailing lists
which are very active:

   * https://groups.google.com/forum/#!forum/ansible-project - for user questions, tips, and tricks
   * https://groups.google.com/forum/#!forum/ansible-devel - for strategy, future planning, and questions about writing code

Thank you once again for this and your interest in Ansible!

