Should This Be Filed Elsewhere?
===============================

Hi!

Thanks very much for your interest in Ansible.  It sincerely means a lot to us. 

This appears to be something that should be filed against another project or bug tracker, and let us explain our reasons for thinking this:

   * FILL IN

If you can stop by the tracker or forum for one of those projects, we'd appreciate it.  

Should you still wish to discuss things further, or if you disagree with our thought process, please stop by one of our two mailing lists:

  * https://groups.google.com/forum/#!forum/ansible-project
  * https://groups.google.com/forum/#!forum/ansible-devel

We'd be happy to discuss things.

Thank you once again!


