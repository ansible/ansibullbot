Ticket Stubs 
============

What's this?

This is a directory of common responses to save some typing when responding to GitHub tickets to avoid
some carpal tunnel syndrome events as Ansible takes off into stratosphere territory.

These are actually on GitHub so it's easy for people to make these snippets of text even more helpful
or to correct typos. 

(It's just expected that folks like @mpdehaan and @jimi-c will be pasting these in though, we'd ask
that others not do this)

If there are questions, email michael@ansible.com!

