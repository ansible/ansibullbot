Question About This One
=======================

Hi!

Thanks very much for your submission to Ansible.  It sincerely means a lot to us that you've taken time to contribute.

Unfortunately, we're not sure if we want this feature in the program, and I don't want this to seem confrontational.  Our reasons for this are:

   * (A) INSERT ITEM HERE

However, we're absolutely always up for discussion.  Since this is a really busy project, we don't always see comments on closed tickets, but want to encourage
open dialog.  You can stop by the development list, and we'd be glad to talk about it - and we might even be persuaded otherwise!

   * https://groups.google.com/forum/#!forum/ansible-devel

In the future, sometimes starting a discussion on the development list prior to implementing a feature can make getting things included a little easier, but it's not always necessary.

Thank you once again for this and your interest in Ansible!

