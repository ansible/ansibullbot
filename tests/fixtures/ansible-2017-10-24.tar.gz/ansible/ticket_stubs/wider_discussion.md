Submission Received
===================

Hi!

Thanks very much for your submission to Ansible.  It sincerely means a lot to us.

We are interested in this idea and would like to see a wider discussion on it
on one of our lists.  Reasons for this include:

   * INSERT REASONS!

Can you please post on ansible-development list so we can talk about this idea with the wider group?

   * https://groups.google.com/forum/#!forum/ansible-devel

Thank you once again for this and your interest in Ansible!

