Possible Misunderstanding
=========================

Hi!

Thanks very much for your submission to Ansible.  It sincerely means a lot to us.

We believe the ticket you have filed is being somewhat misunderstood, as one thing works a little differently than stated.

In particular, we believe you have said:

   * THING ONE

However, however what is happening is that:

   * THING TWO

We would suggest:

   * THING THREE

In the future, this might be a topic more well suited for the user list, which you can also post here if you'd like some more help with the above.
   
   * https://groups.google.com/forum/#!forum/ansible-project

Thank you once again for this and your interest in Ansible!

