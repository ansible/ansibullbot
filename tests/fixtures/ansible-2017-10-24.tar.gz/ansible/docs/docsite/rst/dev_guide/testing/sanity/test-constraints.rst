Sanity Tests » test-constraints
===============================

Constraints for test requirements should be in ``test/runner/requirements/constraints.txt``.
